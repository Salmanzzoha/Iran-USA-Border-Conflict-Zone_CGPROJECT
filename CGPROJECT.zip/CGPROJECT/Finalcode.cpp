#include <windows.h>
#include <GL/glut.h>
#include <math.h>
#include <stdlib.h>
#define PI 3.1416f

//  ANIMATION STATE
float t           = 0.0f;
float heliX       = -120.0f;
float heliY       = 380.0f;
float bladeAngle  = 0.0f;
float wheelAngle  = 0.0f;
float treadShift  = 0.0f;
float flagPhase   = 0.0f;
float spotSweep   = 0.0f;
float cloudShift  = 0.0f;
float fogShift    = 0.0f;
float jetUSAx     = 50.0f;
float jetIRNx     = 974.0f;
float missileT    = 0.0f;
float starTwinkle = 0.0f;
float windowPulse = 0.0f;
float antennaBlink = 0.0f;
float soldierBob  = 0.0f;
float shockwave   = 0.0f;

//satelite
float satX = 180.0f;
float satBaseY = 420.0f;
float satPhase = 0.0f;

// ===  FIX 3: Tank movement
float tankUSAx    = -200.0f;
float tankIRNx    = 1300.0f;
bool  tankUSADone = false;
bool  tankIRNDone = false;
float tankUSATarget = 240.0f;
float tankIRNTarget = 740.0f;

// === FIX 4: 4-stage sky cycle ===
int   skyStage      = 0;
float skyTransition = 0.0f;

// === FIX 6: Board animation ===
float boardX      = -120.0f;
float boardTarget = 476.0f;
bool  boardParked = false;

// === Drone X positions ===
float droneUSAx[3] = { 80.0f, 370.0f, 660.0f };
float droneIRNx[3] = { 944.0f, 654.0f, 364.0f };

//start
enum SceneState {
    INTRO_EXPLOSION,
    INTRO_TEXT,
    NORMAL
};

SceneState sceneState = INTRO_EXPLOSION;
float introT = 0.0f;

//  PARTICLE SYSTEMS

#define MAX_SMOKE 60
struct SmokeP { float x, y, vx, vy, age, life, size; bool alive; };
SmokeP smoke[MAX_SMOKE];

#define MAX_EMBER 40
struct EmberP { float x, y, vx, vy, age, life; bool alive; };
EmberP embers[MAX_EMBER];

#define MAX_DEBRIS 25
struct DebrisP { float x, y, vx, vy, age, life, rot, vrot; bool alive; };
DebrisP debris[MAX_DEBRIS];

float frand(float lo, float hi) {
    return lo + (hi - lo) * ((float)rand() / (float)RAND_MAX);
}

void spawnSmoke() {
    for (int i = 0; i < MAX_SMOKE; i++) {
        if (!smoke[i].alive) {
            smoke[i].x = 512 + frand(-8, 8);
            smoke[i].y = 215 + frand(-3, 3);
            smoke[i].vx = frand(-0.15f, 0.6f);
            smoke[i].vy = frand(0.6f, 1.2f);
            smoke[i].age = 0; smoke[i].life = frand(2.5f, 4.5f);
            smoke[i].size = frand(14, 22); smoke[i].alive = true;
            return;
        }
    }
}


//  HELPER FUNCTIONS
void drawCircle(float cx, float cy, float radius) {
    int segments = 48;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= segments; i++) {
        float a = 2.0f * PI * i / segments;
        glVertex2f(cx + radius * cos(a), cy + radius * sin(a));
    }
    glEnd();
}
void drawEllipse(float cx, float cy, float rx, float ry) {
    int segments = 48;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= segments; i++) {
        float a = 2.0f * PI * i / segments;
        glVertex2f(cx + rx * cos(a), cy + ry * sin(a));
    }
    glEnd();
}
void drawRing(float cx, float cy, float rIn, float rOut,
              float r, float g, float b, float a) {
    int seg = 64;
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(r, g, b, a);
    glBegin(GL_QUAD_STRIP);
    for (int i = 0; i <= seg; i++) {
        float ang = 2.0f * PI * i / seg;
        glVertex2f(cx + rIn  * cos(ang), cy + rIn  * sin(ang));
        glVertex2f(cx + rOut * cos(ang), cy + rOut * sin(ang));
    }
    glEnd();
    glDisable(GL_BLEND);
}
void drawSoftCircle(float cx, float cy, float radius,
                    float r, float g, float b, float innerA, float outerA) {
    int segments = 40;
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_TRIANGLE_FAN);
        glColor4f(r, g, b, innerA); glVertex2f(cx, cy);
        glColor4f(r, g, b, outerA);
        for (int i = 0; i <= segments; i++) {
            float a = 2.0f * PI * i / segments;
            glVertex2f(cx + radius * cos(a), cy + radius * sin(a));
        }
    glEnd();
    glDisable(GL_BLEND);
}
void drawRect(float x1, float y1, float x2, float y2) {
    glBegin(GL_QUADS);
    glVertex2f(x1,y1); glVertex2f(x2,y1);
    glVertex2f(x2,y2); glVertex2f(x1,y2);
    glEnd();
}
void drawGradRect(float x1, float y1, float x2, float y2,
                  float r1, float g1, float b1,
                  float r2, float g2, float b2) {
    glBegin(GL_QUADS);
        glColor3f(r1,g1,b1); glVertex2f(x1,y1);
        glColor3f(r1,g1,b1); glVertex2f(x2,y1);
        glColor3f(r2,g2,b2); glVertex2f(x2,y2);
        glColor3f(r2,g2,b2); glVertex2f(x1,y2);
    glEnd();
}
void drawLine(float x1, float y1, float x2, float y2) {
    glBegin(GL_LINES);
    glVertex2f(x1,y1); glVertex2f(x2,y2);
    glEnd();
}
void drawSemiEllipse(float cx, float cy, float rx, float ry) {
    int segments = 30;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= segments; i++) {
        float a = PI * i / segments;
        glVertex2f(cx + rx * cos(a), cy + ry * sin(a));
    }
    glEnd();
}
void drawText(float x, float y, const char* s) {
    glRasterPos2f(x, y);
    for (const char* c = s; *c; c++) glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *c);
}

// =============================================================================
//  FIX 2: Soldier helper
// =============================================================================
void drawUSASoldierAt(float sx) {
    float sBob = sin(soldierBob) * 0.8f;
    float groundY = 120.0f;
    glColor3f(0.10f, 0.08f, 0.05f);
    drawRect(sx - 5, groundY,
    sx - 1, groundY + 6);
    drawRect(sx + 1, groundY,
    sx + 5, groundY + 6);
    glColor3f(0.30f, 0.36f, 0.20f);
    drawRect(sx - 5, groundY + 6,
    sx - 1, groundY + 18 + sBob);
    drawRect(sx + 1, groundY + 6,
    sx + 5, groundY + 18 + sBob);
    glColor3f(0.32f, 0.40f, 0.22f);
    drawRect(sx - 6, groundY + 16 +
    sBob, sx + 6, groundY + 34 + sBob);
    glColor3f(0.20f, 0.26f, 0.14f);
    drawRect(sx - 5, groundY + 22 + sBob,
    sx + 5, groundY + 30 + sBob);
    float sy = groundY + 38.0f + sBob;
    glColor3f(0.92f, 0.76f, 0.60f);
    drawCircle(sx, sy, 4);
    glColor3f(0.25f, 0.32f, 0.18f);
    drawSemiEllipse(sx, sy + 1, 5, 4);
    glColor3f(0.18f, 0.24f, 0.14f);
    drawLine(sx - 5, sy + 1, sx + 5, sy + 1);
    glColor3f(0.30f, 0.38f, 0.20f);
    glLineWidth(2.5f);
    drawLine(sx - 5, groundY + 30 + sBob,
    sx - 9, groundY + 18 + sBob);
    drawLine(sx + 5, groundY + 30 + sBob,
    sx + 14, groundY + 26 + sBob);
    glLineWidth(1.0f);
    glColor3f(0.10f, 0.10f, 0.10f);
    drawRect(sx + 14, groundY + 23 + sBob,
    sx + 32, groundY + 27 + sBob);
    drawRect(sx + 11, groundY + 22 + sBob,
    sx + 16, groundY + 28 + sBob);
    drawRect(sx + 19, groundY + 27 + sBob,
    sx + 23, groundY + 30 + sBob);
}

void drawIRNSoldierAt(float sx) {
    float sBob = sin(soldierBob + PI) * 0.8f;
    float groundY = 120.0f;
    glColor3f(0.10f, 0.08f, 0.05f);
    drawRect(sx - 5, groundY,
    sx - 1, groundY + 6);
    drawRect(sx + 1, groundY,
    sx + 5, groundY + 6);
    glColor3f(0.42f, 0.30f, 0.18f);
    drawRect(sx - 5, groundY + 6,
    sx - 1, groundY + 18 + sBob);
    drawRect(sx + 1, groundY + 6,
    sx + 5, groundY + 18 + sBob);
    glColor3f(0.46f, 0.34f, 0.22f);
    drawRect(sx - 6, groundY + 16 + sBob,
    sx + 6, groundY + 34 + sBob);
    glColor3f(0.30f, 0.22f, 0.14f);
    drawRect(sx - 5, groundY + 22 + sBob,
    sx + 5, groundY + 30 + sBob);
    float sy = groundY + 38.0f + sBob;
    glColor3f(0.92f, 0.76f, 0.60f);
    drawCircle(sx, sy, 4);
    glColor3f(0.36f, 0.26f, 0.16f);
    drawSemiEllipse(sx, sy + 1, 5, 4);
    glColor3f(0.24f, 0.18f, 0.12f);
    drawLine(sx - 5, sy + 1, sx + 5, sy + 1);
    glColor3f(0.42f, 0.30f, 0.18f);
    glLineWidth(2.5f);
    drawLine(sx + 5, groundY + 30 + sBob,
    sx + 9, groundY + 18 + sBob);
    drawLine(sx - 5, groundY + 30 + sBob,
    sx - 14, groundY + 26 + sBob);
    glLineWidth(1.0f);
    glColor3f(0.10f, 0.10f, 0.10f);
    drawRect(sx - 32, groundY + 23 + sBob,
    sx - 14, groundY + 27 + sBob);
    drawRect(sx - 16, groundY + 22 + sBob,
    sx - 11, groundY + 28 + sBob);
    drawRect(sx - 23, groundY + 27 + sBob,
    sx - 19, groundY + 30 + sBob);
}

// =============================================================================
//  DRONE DRAWING
// =============================================================================
void drawDrone(float x, float y, bool isUSA) {
    if (isUSA) glColor3f(0.20f, 0.28f, 0.16f);
    else       glColor3f(0.48f, 0.36f, 0.20f);
    drawRect(x - 8, y - 3, x + 8, y + 3);
    glColor3f(0.12f, 0.12f, 0.12f);
    glLineWidth(1.5f);
    drawLine(x - 8, y, x - 18, y);
    drawLine(x + 8, y, x + 18, y);
    glLineWidth(1.0f);
    if (isUSA) glColor3f(0.10f, 0.18f, 0.10f);
    else       glColor3f(0.30f, 0.22f, 0.12f);
    drawCircle(x - 18, y, 4.0f);
    drawCircle(x + 18, y, 4.0f);
}
void drawDrones() {
    float baseY = 355.0f;
    for (int i = 0; i < 3; i++) {
        float wave = sin(t * 2.5f + i * 0.9f) * 6.0f;
        drawDrone(droneUSAx[i], baseY + wave, true);
        drawDrone(droneIRNx[i], baseY + wave, false);
    }
}

// =============================================================================
//  FIX 4: 4-Stage Sky
// =============================================================================
struct SkyColor { float r1,g1,b1, r2,g2,b2; };

SkyColor getSkyColor(int stage) {
    switch (stage) {
        case 0: return {0.98f,0.72f,0.40f, 0.70f,0.40f,0.55f};
        case 1: return {0.75f,0.90f,1.00f, 0.30f,0.60f,0.95f};
        case 2: return {1.00f,0.60f,0.25f, 0.90f,0.40f,0.15f};
        default: return {0.06f,0.06f,0.14f, 0.03f,0.04f,0.12f};
    }
}

// =============================================================================
//   Sky, Atmosphere & Explosion
// =============================================================================
void drawZone1_Background() {
    if (skyStage == 0) {
        glColor3f(1.0f, 0.6f, 0.3f);
    }
    else if (skyStage == 1) {
        glColor3f(0.3f, 0.7f, 1.0f);
    }
    else if (skyStage == 2) {
        glColor3f(0.1f, 0.4f, 0.9f);
    }
    else {
        glColor3f(0.0f, 0.0f, 0.0f);
    }

    drawRect(0, 120, 1024, 480);

    float fl = 1.0f + sin(t * 9) * 0.15f + sin(t * 22) * 0.05f;
    drawSoftCircle(512, 130, 320 * fl, 0.55f, 0.30f, 0.15f, 0.22f, 0.0f);

    bool isNight = (skyStage == 3);
    bool isDay   = (skyStage != 3);

    if (isNight) {
        drawSoftCircle(880, 410, 60, 0.95f,0.92f,0.80f, 0.18f, 0.0f);
        glColor3f(0.98f,0.96f,0.85f);
        drawCircle(880, 410, 28);
        glColor3f(0.05f,0.07f,0.18f);
        drawCircle(870, 415, 24);
        glColor3f(0.85f,0.83f,0.72f);
        drawCircle(885,405,3);
        drawCircle(895,415,2);
        drawCircle(880,420,2.5f);

        float stars[20][3] = {
            { 60,440,1.5f},{130,460,1.2f},{200,430,2.2f},
            {270,455,1.4f},{340,425,1.7f},{410,450,1.0f},
            {480,435,1.9f},{560,460,1.3f},{640,440,1.6f},
            {720,455,1.1f},{780,425,1.8f},{950,460,1.3f},
            {800,380,1.0f},{100,400,1.3f},{380,380,1.5f},
            {620,410,1.0f},{310,470,1.4f},{770,460,1.6f},
            {920,380,1.2f},{510,470,1.0f}
        };
        for (int i = 0; i < 20; i++) {
            float tk = sin(starTwinkle + i * 1.3f) * 0.35f + 0.65f;
            drawSoftCircle(stars[i][0],stars[i][1],stars[i][2]*3.0f,
                           1.0f,1.0f,0.85f, 0.30f*tk, 0.0f);
            glColor3f(1.0f*tk,1.0f*tk,0.95f*tk);
            drawCircle(stars[i][0],stars[i][1],stars[i][2]);
        }
    }

    if (isDay) {
        float gr=1.0f,gg=0.85f,gb=0.40f;
        if (skyStage==2) { gr=1.0f; gg=0.55f; gb=0.15f; }
        drawSoftCircle(150, 430, 90, gr,gg,gb, 0.50f, 0.0f);
        glColor3f(1.0f, skyStage==2 ? 0.70f : 0.95f, skyStage==0 ? 0.40f : 0.25f);
        drawCircle(150, 430, 38);
    }

    glColor3f(1.0f, 1.0f, 1.0f);

    float cloudBase[4][3] = {
        {120,415,1.0f},
        {400,445,0.8f},
        {680,420,1.1f},
        {900,440,0.9f}
    };

    for (int c = 0; c < 4; c++) {
        float cx = cloudBase[c][0] + cloudShift * (c + 1) * 0.4f;
        if (cx > 1150) cx -= 1300;
        if (cx < -120) cx += 1300;
        float cy  = cloudBase[c][1];
        float scl = cloudBase[c][2];

        if (isNight) {
            glColor3f(0.20f,0.20f,0.28f);
            drawEllipse(cx,      cy,      58*scl, 20*scl);
            drawEllipse(cx-45,   cy-8,    44*scl, 16*scl);
            drawEllipse(cx+45,   cy-5,    46*scl, 17*scl);
            drawEllipse(cx-10,   cy+10,   38*scl, 14*scl);
        } else {
            if (skyStage == 2)
                glColor3f(1.0f,0.82f,0.68f);
            else
                glColor3f(0.92f,0.92f,0.95f);
            drawEllipse(cx,      cy,      60*scl, 20*scl);
            drawEllipse(cx-50,   cy-10,   45*scl, 17*scl);
            drawEllipse(cx+50,   cy-5,    48*scl, 18*scl);
            drawEllipse(cx-15,   cy+12,   40*scl, 15*scl);
            drawEllipse(cx+20,   cy+10,   36*scl, 14*scl);
        }
    }
}

void drawZone1_Foreground() {
    float sweepUSA = sin(spotSweep) * 50;
    float sweepIRN = sin(spotSweep + PI) * 50;
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_QUAD_STRIP);
        glColor4f(1.0f,0.95f,0.6f,0.55f); glVertex2f(105,350); glVertex2f(118,355);
        glColor4f(1.0f,0.95f,0.6f,0.10f);
        glVertex2f(290+sweepUSA,220); glVertex2f(370+sweepUSA,240);
    glEnd();
    glBegin(GL_QUAD_STRIP);
        glColor4f(1.0f,0.95f,0.6f,0.55f); glVertex2f(919,350); glVertex2f(906,355);
        glColor4f(1.0f,0.95f,0.6f,0.10f);
        glVertex2f(734-sweepIRN,220); glVertex2f(654-sweepIRN,240);
    glEnd();
    glDisable(GL_BLEND);

    float fl = 1.0f + sin(t*18)*0.12f + sin(t*41)*0.06f;
    float sw = shockwave;
    if (sw < 1.0f) {
        float radius = 30 + sw * 180;
        drawRing(512,200,radius-4,radius,
        1.0f,0.85f,0.4f,  0.7f*(1.0f-sw));
        drawRing(512,200,radius-8,radius-4,
        1.0f,0.5f,0.15f,  0.4f*(1.0f-sw));
    }
    drawSoftCircle(512,200,90.0f*fl,1.0f,0.55f,0.15f,0.60f,0.0f);
    drawSoftCircle(512,200,60.0f*fl,1.0f,0.40f,0.05f,0.85f,0.0f);
    glColor3f(1.0f,0.35f,0.05f); drawCircle(512,200,32*fl);
    glColor3f(1.0f,0.95f,0.55f); drawCircle(512,200,18*fl);
    glColor3f(1.0f,1.0f,0.85f);  drawCircle(512,200, 7*fl);

    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    for (int i = 0; i < MAX_SMOKE; i++) {
        if (!smoke[i].alive) continue;
        float a = smoke[i].age / smoke[i].life;
        float alpha = (1.0f-a)*0.65f;
        float gray  = 0.25f + a*0.35f;
        float size  = smoke[i].size*(1.0f+a*1.4f);
        glColor4f(gray,gray,gray+0.02f,alpha*0.5f);
        drawEllipse(smoke[i].x,smoke[i].y,size*1.4f,size*0.85f);
        glColor4f(gray,gray,gray+0.02f,alpha);
        drawEllipse(smoke[i].x,smoke[i].y,size,size*0.6f);
    }
    glDisable(GL_BLEND);

    if (missileT < 1.0f) {
        float startX=1000,startY=460,endX=535,endY=215;
        float mx=startX+(endX-startX)*missileT;
        float my=startY+(endY-startY)*missileT;
        glColor3f(0.85f,0.85f,0.85f); glLineWidth(2.0f);
        glEnable(GL_LINE_STIPPLE); glLineStipple(2,0x00FF);
        float trailX=mx+(startX-endX)*0.20f;
        float trailY=my+(startY-endY)*0.20f;
        if (trailX>startX) trailX=startX;
        drawLine(trailX,trailY,mx,my);
        glDisable(GL_LINE_STIPPLE); glLineWidth(1.0f);
        drawSoftCircle(mx,my,14,1.0f,0.7f,0.3f,0.7f,0.0f);
        glColor3f(1.0f,0.5f,0.2f);
        glBegin(GL_TRIANGLES);
            glVertex2f(mx,my);
            glVertex2f(mx+10,my+5);
             glVertex2f(mx+10,my-5);
        glEnd();
    }

    float sp=fmod(t*2.0f,1.0f);
    glColor4f(1.0f,0.85f,0.3f,1.0f-sp);
    glEnable(GL_BLEND); glLineWidth(1.8f);
    glBegin(GL_LINES);
    for (int i=0;i<8;i++) {
        float ang=i*(PI/4.0f)+sin(t)*0.1f;
        float r1=25+sp*10, r2=50+sp*30;
        glVertex2f(512+r1*cos(ang),200+r1*sin(ang));
        glVertex2f(512+r2*cos(ang),200+r2*sin(ang));
    }
    glEnd();
    glLineWidth(1.0f); glDisable(GL_BLEND);
}

// =============================================================================
//   Border Zone, Fence & Ground
// =============================================================================
void drawZone2_Border() {
    drawGradRect(0,0,500,120, 0.42f,0.34f,0.22f, 0.30f,0.26f,0.20f);
    drawGradRect(524,0,1024,120, 0.46f,0.36f,0.24f, 0.32f,0.28f,0.22f);
    glColor3f(0.25f,0.20f,0.14f);
    float rocks[18][2]={{50,40},{120,30},{200,55},{280,25},{350,50},{420,35},
                        {580,40},{640,55},{710,30},{780,50},{860,30},{940,45},
                        {90,80},{260,75},{390,90},{600,85},{720,75},{890,85}};
    for (int i=0;i<18;i++) drawCircle(rocks[i][0],rocks[i][1],2.5f);
    glColor3f(0.55f,0.46f,0.30f);
    for (int i=0;i<10;i++) { float x=30+i*95; drawLine(x,30,x+25,35); }

    drawGradRect(500,0,524,280, 0.18f,0.18f,0.20f, 0.30f,0.30f,0.32f);
    glColor3f(0.12f,0.12f,0.14f);
    for (int y=30;y<280;y+=30) drawLine(500,y,524,y);
    glColor3f(0.55f,0.55f,0.58f); glLineWidth(1.2f);
    for (int row=0;row<3;row++) {
        float yTop=200+row*20;
        glBegin(GL_LINE_STRIP);
            glVertex2f(485,yTop);
             glVertex2f(512,yTop-2);
             glVertex2f(539,yTop);
        glEnd();
    }
    glLineWidth(1.0f);
    drawGradRect(485,0,500,290, 0.25f,0.25f,0.27f, 0.18f,0.18f,0.20f);
    drawGradRect(524,0,539,290, 0.25f,0.25f,0.27f, 0.18f,0.18f,0.20f);

    glColor3f(0.55f,0.55f,0.58f);
    glLineWidth(1.2f);
    glBegin(GL_LINE_STRIP);
    for (int x=20;x<=480;x+=20) {
        float y=105.0f+(((x/20)%2==0)?6.0f:0.0f);
        glVertex2f((float)x,y);
    }
    glEnd();
    glBegin(GL_LINE_STRIP);
    for (int x=544;x<=1004;x+=20) {
        float y=105.0f+(((x/20)%2==0)?6.0f:0.0f);
        glVertex2f((float)x,y);
    }
    glEnd();
    for (int x=30;x<=470;x+=40) {
        drawLine(x,108,x-2,113); drawLine(x,108,x+2,113);
    }
    for (int x=554;x<=994;x+=40) {
        drawLine(x,108,x-2,113); drawLine(x,108,x+2,113);
    }
    glLineWidth(1.0f);

    for (int side=0;side<2;side++) {
        float baseX=(side==0)?440:584;
        for (int row=0;row<3;row++) {
            float y=95.0f+row*13.0f;
            float x=baseX+(row%2==0?0:(side==0?8:-8));
            glColor3f(0.68f+side*0.05f,0.58f,0.38f);
            drawEllipse(x,y,18,7);
            glColor3f(0.80f+side*0.03f,0.70f,0.48f);
            drawEllipse(x,y+2,14,3);
            glColor3f(0.40f,0.32f,0.20f);
            drawCircle(x,y+3,1.2f);
        }
    }
    glColor3f(0.10f,0.08f,0.05f);
    drawSemiEllipse(180,100,25,30);
    glColor3f(0.32f,0.27f,0.20f);
    drawSemiEllipse(180,100,22,28);
    glColor3f(0.05f,0.04f,0.02f);
    drawSemiEllipse(180,100,14,20);
    glColor3f(0.16f,0.12f,0.08f);
    drawRect(40,90,380,96);
    drawRect(644,90,984,96);
    glColor3f(0.40f,0.34f,0.22f);
    drawLine(40,96,380,96);
    drawLine(644,96,984,96);
    glColor3f(0.85f,0.10f,0.10f);
    drawRect(470,128,554,134);
    glColor3f(1.0f,1.0f,1.0f);
    for (int x=478;x<554;x+=16)
        drawRect(x,128,x+8,134);
    for (int p=0;p<2;p++) {
        float x=(p==0)?467:551;
        drawGradRect(x,110,x+6,145, 0.95f,0.95f,0.95f, 0.65f,0.65f,0.65f);
        glColor3f(0.20f,0.20f,0.20f);
    drawRect(x-1,145,x+7,148);
    }
}

// =============================================================================
//  Helper: Waving flag strip
// =============================================================================
void drawWavingStripe(float x1, float yBot, float yTop, float w,
                      float r, float g, float b, float phase) {
    int seg=12;
    glColor3f(r,g,b);
    glBegin(GL_QUAD_STRIP);
    for (int i=0;i<=seg;i++) {
        float u=(float)i/seg;
        float x=x1+u*w;
        float wave=sin(u*4+phase)*3.0f*u;
        glVertex2f(x,yBot+wave); glVertex2f(x,yTop+wave);
    }
    glEnd();
}

// =============================================================================
//  Helper: Rolling tank tread
// =============================================================================
void drawTankWheels(float wx[3], float wy, float r, float wheelAng) {
    for (int i=0;i<3;i++) {
        glColor3f(0.08f,0.08f,0.08f);
        drawCircle(wx[i],wy,r);
        glPushMatrix();
        glTranslatef(wx[i],wy,0);
        glRotatef(wheelAng,0,0,1);
        glColor3f(0.30f,0.30f,0.30f);
        drawCircle(0,0,5);
        glColor3f(0.10f,0.10f,0.10f);
        glLineWidth(1.5f);
        glBegin(GL_LINES);
            glVertex2f(-5,0);
            glVertex2f(5,0);
            glVertex2f(0,-5);
            glVertex2f(0,5);
        glEnd();
        glLineWidth(1.0f);
        glPopMatrix();
    }
}
void drawScrollingTread(float x1, float x2, float y1, float y2, float shift) {
    glColor3f(0.05f,0.05f,0.05f); drawRect(x1,y1,x2,y2);
    glColor3f(0.12f,0.12f,0.12f);
    float spacing=8.0f, offset=fmod(shift,spacing);
    for (float x=x1+offset;x<x2;x+=spacing) {
        float xa=x, xb=x+5;
        if (xa<x1) xa=x1; if (xb>x2) xb=x2;
        if (xb>xa) drawRect(xa,y1,xb,y1+4);
    }
}

// =============================================================================
//  MEMBER 3 — USA Side
// =============================================================================
void drawZone3_USA() {
    glColor3f(0.20f,0.25f,0.14f);
    drawRect(98,120,122,200);
    glColor3f(0.15f,0.20f,0.10f);
    drawLine(98,120,122,200);
    drawLine(122,120,98,200);
    drawGradRect(80,200,140,320, 0.22f,0.30f,0.16f, 0.30f,0.40f,0.20f);
    glColor3f(0.16f,0.22f,0.10f);
    drawLine(95,200,95,320);
    drawLine(110,200,110,320);
    drawLine(125,200,125,320);
    glColor3f(0.15f,0.20f,0.10f);
    drawRect(68,318,152,322);
    drawGradRect(70,322,150,350, 0.20f,0.28f,0.13f, 0.28f,0.36f,0.18f);

    glColor3f(0.10f,0.10f,0.10f);
    glLineWidth(1.5f);
    drawLine(110,350,110,365);
    glLineWidth(1.0f);
    float blink=(sin(antennaBlink)>0)?1.0f:0.2f;
    drawSoftCircle(110,366,5,1.0f,0.1f,0.1f,0.8f*blink,0.0f);
    glColor3f(blink,0.1f*blink,0.1f*blink); drawCircle(110,366,1.8f);

    float wp=0.3f+sin(windowPulse)*0.05f;
    drawSoftCircle(95,270,22,1.0f,0.85f,0.5f,wp,0.0f);
    drawSoftCircle(125,270,22,1.0f,0.85f,0.5f,wp,0.0f);
    glColor3f(0.85f,0.78f,0.55f);
    drawRect(88,260,102,280);
    drawRect(118,260,132,280);
    glColor3f(0.10f,0.12f,0.08f);
    drawLine(95,260,95,280);
    drawLine(125,260,125,280);
    drawLine(88,270,102,270);
    drawLine(118,270,132,270);

    float poleX = 75.0f;
    glColor3f(0.85f,0.85f,0.85f);
    glLineWidth(2.0f);
    drawLine(poleX, 322, poleX, 418);
    glLineWidth(1.0f);

    float fx=poleX, fy=380, fw=50;
    for (int i=0;i<7;i++) {
        float r=(i%2==0)?0.78f:0.95f;
        float g=(i%2==0)?0.10f:0.95f;
        float b=(i%2==0)?0.10f:0.95f;
        drawWavingStripe(fx,fy+i*5,fy+(i+1)*5,fw,r,g,b,flagPhase);
    }
    glColor3f(0.10f,0.18f,0.50f);
    glBegin(GL_QUAD_STRIP);
    for (int i=0;i<=8;i++) {
        float u=(float)i/8;
        float x=fx+u*22;
        float wave=sin(u*4+flagPhase)*3.0f*u;
        glVertex2f(x,400+wave); glVertex2f(x,415+wave);
    }
    glEnd();
    glColor3f(1,1,1);
    for (int i=0;i<3;i++)
        for (int j=0;j<4;j++) {
            float u=((float)i*7+3)/22;
            float wave=sin(u*4+flagPhase)*3.0f*u;
            drawCircle(fx+3.0f+i*7, 402.0f+j*4+wave, 0.6f);
        }

    float tx = tankUSAx;
    drawScrollingTread(tx,      tx+124, 96, 124, treadShift);
    drawGradRect(tx-8,  122, tx+132, 145, 0.16f,0.24f,0.12f, 0.26f,0.36f,0.18f);
    glColor3f(0.10f,0.16f,0.08f);
    drawRect(tx+27, 142, tx+97, 145);
    glColor3f(0.20f,0.30f,0.14f);
    drawRect(tx+27, 145, tx+97, 168);
    drawEllipse(tx+62, 168, 36, 6);
    glColor3f(0.10f,0.14f,0.08f); drawCircle(tx+62, 165, 5);
    glColor3f(0.20f,0.28f,0.14f); drawCircle(tx+62, 166, 3);
    glColor3f(0.12f,0.16f,0.08f);
    drawRect(tx+95,  152, tx+192, 162);
    glColor3f(0.05f,0.05f,0.05f);
    drawRect(tx+190, 151, tx+197, 163);
    drawCircle(tx+197, 157, 2);
    float wx[3]={tx+17, tx+62, tx+107};
    drawTankWheels(wx, 110, 14, wheelAngle);
    glColor3f(0.30f,0.40f,0.20f);
    drawRect(tx-3,  130, tx+7,  145);
    glColor3f(0.15f,0.20f,0.10f);
    drawRect(tx,    144, tx+4,  147);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(1.0f,0.45f,0.15f,0.18f);
    glDisable(GL_BLEND);

    float soldierYOffset = -25.0f;
    float sBob=sin(soldierBob)*0.8f;
    float groundY=120.0f;
    float sx=395;
    glColor3f(0.10f,0.08f,0.05f);
    drawRect(sx-5,groundY,    sx-1,groundY+6);
    drawRect(sx+1,groundY,    sx+5,groundY+6);
    glColor3f(0.30f,0.36f,0.20f);
    drawRect(sx-5,groundY+6,  sx-1,groundY+18+sBob);
    drawRect(sx+1,groundY+6,  sx+5,groundY+18+sBob);
    glColor3f(0.32f,0.40f,0.22f);
    drawRect(sx-6,groundY+16+sBob,sx+6,groundY+34+sBob);
    glColor3f(0.20f,0.26f,0.14f);
    drawRect(sx-5,groundY+22+sBob,sx+5,groundY+30+sBob);
    glColor3f(0.92f,0.76f,0.60f);
    float sy=groundY+38+sBob;
    drawCircle(sx,sy,4);
    glColor3f(0.25f,0.32f,0.18f); drawSemiEllipse(sx,sy+1,5,4);
    glColor3f(0.18f,0.24f,0.14f); drawLine(sx-5,sy+1,sx+5,sy+1);
    glColor3f(0.30f,0.38f,0.20f); glLineWidth(2.5f);
    drawLine(sx-5,groundY+30+sBob,sx-9,groundY+18+sBob);
    drawLine(sx+5,groundY+30+sBob,sx+14,groundY+26+sBob);
    glLineWidth(1.0f);
    glColor3f(0.10f,0.10f,0.10f);
    drawRect(sx+14,groundY+23+sBob,sx+32,groundY+27+sBob);
    drawRect(sx+11,groundY+22+sBob,sx+16,groundY+28+sBob);
    drawRect(sx+19,groundY+27+sBob,sx+23,groundY+30+sBob);

    drawUSASoldierAt(157.0f);
    drawUSASoldierAt(172.0f);
    drawUSASoldierAt(187.0f);

    glPushMatrix();
    glTranslatef(jetUSAx-95,0,0);
    glColor3f(0.45f,0.48f,0.55f);
    glBegin(GL_POLYGON);
        glVertex2f(50,425);glVertex2f(140,432);glVertex2f(170,428);
        glVertex2f(140,422);glVertex2f(50,418);
    glEnd();
    glColor3f(0.20f,0.30f,0.45f);
    glBegin(GL_POLYGON);
        glVertex2f(125,430);glVertex2f(150,428);glVertex2f(140,425);glVertex2f(125,425);
    glEnd();
    glColor3f(0.40f,0.43f,0.50f);
    glBegin(GL_TRIANGLES);
        glVertex2f(85,430);glVertex2f(115,448);glVertex2f(120,432);
    glEnd();
    glBegin(GL_TRIANGLES);
        glVertex2f(85,420);glVertex2f(115,402);glVertex2f(120,418);
    glEnd();
    glBegin(GL_TRIANGLES);
        glVertex2f(60,425);glVertex2f(55,438);glVertex2f(75,428);
    glEnd();
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    float jetGlow=0.6f+sin(t*25)*0.2f;
    drawSoftCircle(50,425,10,1.0f,0.5f,0.2f,jetGlow,0.0f);
    glDisable(GL_BLEND);
    glPopMatrix();
}

// =============================================================================
//  MEMBER 4 — Iran Side
// =============================================================================
void drawZone4_Iran() {
    glColor3f(0.32f,0.25f,0.15f);
    drawRect(902,120,926,200);
    glColor3f(0.22f,0.16f,0.10f);
    drawLine(902,120,926,200);
    drawLine(926,120,902,200);
    drawGradRect(884,200,944,320, 0.40f,0.30f,0.18f, 0.55f,0.42f,0.25f);
    glColor3f(0.32f,0.24f,0.14f);
    drawLine(899,200,899,320);
    drawLine(914,200,914,320);
    drawLine(929,200,929,320);
    glColor3f(0.30f,0.22f,0.12f);
    drawRect(872,318,956,322);
    drawGradRect(874,322,954,350, 0.36f,0.27f,0.15f, 0.46f,0.34f,0.20f);

    glColor3f(0.10f,0.10f,0.10f);
    glLineWidth(1.5f);
    drawLine(914,350,914,365);
    glLineWidth(1.0f);
    float blink=(sin(antennaBlink+PI)>0)?1.0f:0.2f;
    drawSoftCircle(914,366,5,0.1f,1.0f,0.3f,0.8f*blink,0.0f);
    glColor3f(0.1f*blink,blink,0.3f*blink); drawCircle(914,366,1.8f);

    float wp=0.3f+sin(windowPulse+PI/2)*0.05f;
    drawSoftCircle(899,270,22,1.0f,0.85f,0.5f,wp,0.0f);
    drawSoftCircle(929,270,22,1.0f,0.85f,0.5f,wp,0.0f);
    glColor3f(0.85f,0.78f,0.55f);
    drawRect(892,260,906,280);
    drawRect(922,260,936,280);
    glColor3f(0.10f,0.08f,0.05f);
    drawLine(899,260,899,280);
    drawLine(929,260,929,280);
    drawLine(892,270,906,270);
    drawLine(922,270,936,270);

    float poleX = 960.0f;
    glColor3f(0.85f,0.85f,0.85f);
    glLineWidth(2.0f);
    drawLine(poleX, 322, poleX, 418);
    glLineWidth(1.0f);

    int seg=12;
    float fxR=poleX, fxL=poleX-50;
    glColor3f(0.0f,0.55f,0.30f);
    glBegin(GL_QUAD_STRIP);
    for (int i=0;i<=seg;i++) {
        float u=(float)i/seg;
        float x=fxL+u*(fxR-fxL);
        float wave=sin((1-u)*4+flagPhase)*3.0f*(1-u);
        glVertex2f(x,405+wave); glVertex2f(x,418+wave);
    }
    glEnd();
    glColor3f(0.95f,0.95f,0.95f);
    glBegin(GL_QUAD_STRIP);
    for (int i=0;i<=seg;i++) {
        float u=(float)i/seg;
        float x=fxL+u*(fxR-fxL);
        float wave=sin((1-u)*4+flagPhase)*3.0f*(1-u);
        glVertex2f(x,392+wave); glVertex2f(x,405+wave);
    }
    glEnd();
    glColor3f(0.82f,0.10f,0.10f);
    glBegin(GL_QUAD_STRIP);
    for (int i=0;i<=seg;i++) {
        float u=(float)i/seg;
        float x=fxL+u*(fxR-fxL);
        float wave=sin((1-u)*4+flagPhase)*3.0f*(1-u);
        glVertex2f(x,379+wave); glVertex2f(x,392+wave);
    }
    glEnd();
    {
        float u=(fxL+25-fxL)/(fxR-fxL);
        float wave=sin((1-u)*4+flagPhase)*3.0f*(1-u);
        glColor3f(0.82f,0.10f,0.10f);
        drawCircle(fxL+25,398+wave,4);
        glColor3f(0.95f,0.95f,0.95f);
        drawCircle(fxL+25,398+wave,1.5f);
        drawLine(fxL+25,394+wave,fxL+25,402+wave);
        drawLine(fxL+21,398+wave,fxL+29,398+wave);
    }

    float tx = tankIRNx - 132;
    drawScrollingTread(tx,tx+124, 96, 124, treadShift);
    drawGradRect(tx-8,  122, tx+140, 145, 0.50f,0.42f,0.26f, 0.65f,0.55f,0.35f);
    glColor3f(0.40f,0.32f,0.20f);
    drawRect(tx+27, 142, tx+97, 145);
    glColor3f(0.62f,0.52f,0.32f);
    drawRect(tx+27, 145, tx+97, 168);
    drawEllipse(tx+70, 168, 36, 6);
    glColor3f(0.30f,0.24f,0.14f);
    drawCircle(tx+70, 165, 5);
    glColor3f(0.55f,0.45f,0.28f);
    drawCircle(tx+70, 166, 3);
    glColor3f(0.40f,0.32f,0.20f);
    drawRect(tx-60, 152, tx+27,  162);
    glColor3f(0.05f,0.05f,0.05f);
    drawRect(tx-67, 151, tx-60,  163);
    drawCircle(tx-67, 157, 2);
    float wx[3]={tx+25, tx+70, tx+115};
    drawTankWheels(wx, 110, 14, wheelAngle);
    glColor3f(0.55f,0.42f,0.25f);
    drawRect(tx+125, 130, tx+135, 145);
    glColor3f(0.30f,0.22f,0.12f);
    drawRect(tx+128, 144, tx+132, 147);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(1.0f,0.45f,0.15f,0.20f);
    glDisable(GL_BLEND);

    float sBob=sin(soldierBob+PI)*0.8f;
    float groundY=120.0f;
    float sx=630;
    glColor3f(0.10f,0.08f,0.05f);
    drawRect(sx-5,groundY,sx-1,groundY+6);
    drawRect(sx+1,groundY,sx+5,groundY+6);
    glColor3f(0.42f,0.30f,0.18f);
    drawRect(sx-5,groundY+6,  sx-1,groundY+18+sBob);
    drawRect(sx+1,groundY+6,  sx+5,groundY+18+sBob);
    glColor3f(0.46f,0.34f,0.22f);
    drawRect(sx-6,groundY+16+sBob,sx+6,groundY+34+sBob);
    glColor3f(0.30f,0.22f,0.14f);
    drawRect(sx-5,groundY+22+sBob,sx+5,groundY+30+sBob);
    glColor3f(0.92f,0.76f,0.60f);
    float sy2=groundY+38+sBob;
    drawCircle(sx,sy2,4);
    glColor3f(0.36f,0.26f,0.16f); drawSemiEllipse(sx,sy2+1,5,4);
    glColor3f(0.24f,0.18f,0.12f); drawLine(sx-5,sy2+1,sx+5,sy2+1);
    glColor3f(0.42f,0.30f,0.18f); glLineWidth(2.5f);
    drawLine(sx+5,groundY+30+sBob,sx+9,groundY+18+sBob);
    drawLine(sx-5,groundY+30+sBob,sx-14,groundY+26+sBob);
    glLineWidth(1.0f);
    glColor3f(0.10f,0.10f,0.10f);
    drawRect(sx-32,groundY+23+sBob,sx-14,groundY+27+sBob);
    drawRect(sx-16,groundY+22+sBob,sx-11,groundY+28+sBob);
    drawRect(sx-23,groundY+27+sBob,sx-19,groundY+30+sBob);

    drawIRNSoldierAt(860.0f);
    drawIRNSoldierAt(845.0f);
    drawIRNSoldierAt(830.0f);

    glPushMatrix();
    glTranslatef(jetIRNx-974,0,0);
    glColor3f(0.50f,0.42f,0.28f);
    glBegin(GL_POLYGON);
        glVertex2f(974,425);glVertex2f(884,432);glVertex2f(854,428);
        glVertex2f(884,422);glVertex2f(974,418);
    glEnd();
    glColor3f(0.30f,0.20f,0.10f);
    glBegin(GL_POLYGON);
        glVertex2f(899,430);glVertex2f(874,428);glVertex2f(884,425);glVertex2f(899,425);
    glEnd();
    glColor3f(0.45f,0.38f,0.25f);
    glBegin(GL_TRIANGLES);
        glVertex2f(939,430);glVertex2f(909,448);glVertex2f(904,432);
    glEnd();
    glBegin(GL_TRIANGLES);
        glVertex2f(939,420);glVertex2f(909,402);glVertex2f(904,418);
    glEnd();
    glBegin(GL_TRIANGLES);
        glVertex2f(964,425);glVertex2f(969,438);glVertex2f(949,428);
    glEnd();
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    float jetGlow=0.6f+sin(t*25+PI)*0.2f;
    drawSoftCircle(974,425,10,1.0f,0.5f,0.2f,jetGlow,0.0f);
    glDisable(GL_BLEND);
    glPopMatrix();
}

// =============================================================================
//  HELICOPTER
// =============================================================================
void drawHelicopter() {
    glPushMatrix();
    glTranslatef(heliX,heliY,0);
    glRotatef(4,0,0,1);
    float beamSwing=cos(t*1.5f)*12.0f;
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glBegin(GL_QUAD_STRIP);
        glColor4f(1.0f,0.95f,0.7f,0.45f); glVertex2f(20,-6); glVertex2f(35,-6);
        glColor4f(1.0f,0.95f,0.7f,0.0f);
        glVertex2f(-30+beamSwing,-90); glVertex2f(80+beamSwing,-90);
    glEnd();
    glDisable(GL_BLEND);
    glBegin(GL_POLYGON);
        glColor3f(0.18f,0.22f,0.22f); glVertex2f(-40,-10);
        glColor3f(0.22f,0.26f,0.26f); glVertex2f(20,-10);
        glColor3f(0.26f,0.30f,0.30f); glVertex2f(40,0);
        glColor3f(0.30f,0.34f,0.34f); glVertex2f(20,12);
        glColor3f(0.20f,0.24f,0.24f); glVertex2f(-40,10);
    glEnd();
    glColor3f(0.10f,0.12f,0.12f); drawRect(-40,-12,20,-9);
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    glColor4f(0.20f,0.40f,0.55f,0.85f);
    glBegin(GL_POLYGON);
        glVertex2f(10,-5); glVertex2f(30,0); glVertex2f(10,8);
    glEnd();
    glDisable(GL_BLEND);
    glColor3f(0.45f,0.55f,0.60f);
    glBegin(GL_LINE_LOOP);
        glVertex2f(10,-5); glVertex2f(30,0); glVertex2f(10,8);
    glEnd();
    glColor3f(0.10f,0.18f,0.25f); drawRect(-5,-2,10,6);
    glColor3f(0.10f,0.12f,0.12f); drawLine(-15,-10,-15,10);
    glColor3f(0.20f,0.24f,0.24f); drawRect(-90,-3,-40,3);
    glColor3f(0.14f,0.18f,0.18f); drawRect(-90,-3,-40,-1);
    glColor3f(0.22f,0.26f,0.26f);
    glBegin(GL_TRIANGLES);
        glVertex2f(-90,3); glVertex2f(-100,18); glVertex2f(-78,8);
    glEnd();
    glColor3f(0.18f,0.22f,0.22f); drawRect(-95,-2,-82,1);
    glPushMatrix();
    glTranslatef(-95,8,0); glRotatef(bladeAngle*3,0,0,1);
    glColor3f(0.05f,0.05f,0.05f); glLineWidth(1.5f);
    glBegin(GL_LINES);
        glVertex2f(-7,0); glVertex2f(7,0); glVertex2f(0,-7); glVertex2f(0,7);
    glEnd();
    glLineWidth(1.0f);
    drawSoftCircle(0,0,8,0.3f,0.3f,0.3f,0.25f,0.0f);
    glPopMatrix();
    glPushMatrix();
    glTranslatef(0,14,0); glRotatef(bladeAngle,0,0,1);
    glColor3f(0.05f,0.05f,0.05f);
    for (int i=0;i<4;i++) {
        glRotatef(90,0,0,1);
        glBegin(GL_QUADS);
            glVertex2f(0,-1.2f); glVertex2f(60,-1.2f);
            glVertex2f(60,1.2f); glVertex2f(0,1.2f);
        glEnd();
    }
    glPopMatrix();
    drawSoftCircle(0,14,60,0.4f,0.4f,0.4f,0.10f,0.0f);
    glColor3f(0.10f,0.10f,0.10f); drawRect(-2,12,2,16);
    glColor3f(0.30f,0.30f,0.30f); drawCircle(0,14,3);
    float pulse=(sin(t*6)>0)?1.0f:0.4f;
    drawSoftCircle(-40,0,7,1.0f,0.0f,0.0f,0.9f*pulse,0.0f);
    drawSoftCircle(40,0,7,0.0f,1.0f,0.0f,0.9f*pulse,0.0f);
    drawSoftCircle(-100,18,6,1.0f,1.0f,1.0f,0.8f*pulse,0.0f);
    glColor3f(1.0f*pulse,0.2f*pulse,0.2f*pulse); drawCircle(-40,0,1.5f);
    glColor3f(0.2f*pulse,1.0f*pulse,0.2f*pulse); drawCircle(40,0,1.5f);
    glColor3f(pulse,pulse,pulse);                 drawCircle(-100,18,1.2f);
    glColor3f(0.08f,0.08f,0.08f); glLineWidth(2.0f);
    drawLine(-25,-10,-32,-22); drawLine(-32,-22,28,-22);
    drawLine(28,-22,32,-10);   drawLine(-12,-10,-12,-22);
    drawLine(12,-10,12,-22);   glLineWidth(1.0f);
    glPopMatrix();
}

void drawSatellite()
{
    float y = satBaseY + sin(satPhase) * 20.0f;
    glPushMatrix();
    glTranslatef(satX, y, 0);
    glRotatef(15.0f * sin(satPhase * 0.5f), 0, 0, 1);
    glColor3f(0.78f, 0.78f, 0.82f);
    drawRect(-6, -20, 6, 20);
    glColor3f(0.55f, 0.55f, 0.60f);
    drawRect(-3, -12, 3, 12);
    glColor3f(0.10f, 0.25f, 0.55f);
    drawRect(-45, -10, -6, 10);
    drawRect(6, -10, 45, 10);
    glColor3f(0.05f, 0.15f, 0.35f);
    for (int i = -35; i <= -10; i += 10)
        drawLine(i, -10, i, 10);
    for (int i = 10; i <= 35; i += 10)
        drawLine(i, -10, i, 10);
    glPopMatrix();
}

// =============================================================================
//  INTRO CINEMATIC — drawIntroExplosion (UPDATED)
//  Screen: gluOrtho2D(0,1024, 0,480)  →  center = (512, 240)
//  Phase p goes 0→1 over 2 seconds.
//  Left  fireball: starts at x=-150, arrives at 512
//  Right fireball: starts at x=1174, arrives at 512
// =============================================================================
void drawIntroExplosion(float iT)
{
    float p = iT / 2.0f;            // 0 → 1
    if (p > 1.0f) p = 1.0f;

    float cy   = 240.0f;            // vertical center of screen
    float cx   = 512.0f;            // horizontal center

    // --- fireballs travel toward center ---
    float leftX  = -150.0f + p * 662.0f;   // -150 → 512
    float rightX = 1174.0f - p * 662.0f;   // 1174 → 512

    // fireball radius grows as it moves
    float fRadius = 45.0f + p * 55.0f;

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // --- LEFT fireball (orange/yellow) ---
    drawSoftCircle(leftX, cy, fRadius * 2.2f, 1.0f, 0.30f, 0.00f, 0.30f, 0.0f);
    drawSoftCircle(leftX, cy, fRadius * 1.4f, 1.0f, 0.55f, 0.05f, 0.70f, 0.0f);
    glColor3f(1.0f, 0.75f, 0.20f); drawCircle(leftX, cy, fRadius);
    glColor3f(1.0f, 0.95f, 0.60f); drawCircle(leftX, cy, fRadius * 0.55f);
    glColor3f(1.0f, 1.0f, 0.90f); drawCircle(leftX, cy, fRadius * 0.25f);

    // spark lines radiating from left fireball
    glColor4f(1.0f, 0.80f, 0.30f, 0.75f);
    glLineWidth(1.5f);
    glBegin(GL_LINES);
    for (int i = 0; i < 8; i++) {
        float ang = i * (PI / 4.0f);
        float r1  = fRadius * 0.7f;
        float r2  = fRadius * 1.6f;
        glVertex2f(leftX + r1 * cos(ang), cy + r1 * sin(ang));
        glVertex2f(leftX + r2 * cos(ang), cy + r2 * sin(ang));
    }
    glEnd();
    glLineWidth(1.0f);

    // --- RIGHT fireball (red/orange) ---
    drawSoftCircle(rightX, cy, fRadius * 2.2f, 1.0f, 0.10f, 0.00f, 0.30f, 0.0f);
    drawSoftCircle(rightX, cy, fRadius * 1.4f, 1.0f, 0.35f, 0.00f, 0.70f, 0.0f);
    glColor3f(1.0f, 0.50f, 0.10f); drawCircle(rightX, cy, fRadius);
    glColor3f(1.0f, 0.85f, 0.40f); drawCircle(rightX, cy, fRadius * 0.55f);
    glColor3f(1.0f, 1.0f, 0.90f); drawCircle(rightX, cy, fRadius * 0.25f);

    glColor4f(1.0f, 0.60f, 0.20f, 0.75f);
    glLineWidth(1.5f);
    glBegin(GL_LINES);
    for (int i = 0; i < 8; i++) {
        float ang = i * (PI / 4.0f);
        float r1  = fRadius * 0.7f;
        float r2  = fRadius * 1.6f;
        glVertex2f(rightX + r1 * cos(ang), cy + r1 * sin(ang));
        glVertex2f(rightX + r2 * cos(ang), cy + r2 * sin(ang));
    }
    glEnd();
    glLineWidth(1.0f);

    // --- COLLISION FLASH when p > 0.82 ---
    if (p > 0.82f) {
        float flash = (p - 0.82f) / 0.18f;   // 0 → 1 during final 18% of phase

        // large outer glow
        drawSoftCircle(cx, cy, 280.0f * flash, 1.0f, 0.60f, 0.10f, 0.55f * flash, 0.0f);
        // mid glow
        drawSoftCircle(cx, cy, 170.0f * flash, 1.0f, 0.75f, 0.20f, 0.85f * flash, 0.0f);
        // bright core
        drawSoftCircle(cx, cy, 90.0f  * flash, 1.0f, 0.90f, 0.60f, 1.0f,          0.0f);
        // white-hot center
        glColor3f(1.0f, 1.0f, 1.0f);
        drawCircle(cx, cy, 40.0f * flash);

        // shockwave ring expanding outward
        float ringR = 60.0f + flash * 220.0f;
        drawRing(cx, cy, ringR - 6.0f, ringR,
                 1.0f, 0.80f, 0.30f, 0.90f * (1.0f - flash));
        drawRing(cx, cy, ringR - 14.0f, ringR - 6.0f,
                 1.0f, 0.40f, 0.10f, 0.50f * (1.0f - flash));
    }

    glDisable(GL_BLEND);
}

// =============================================================================
//  INTRO CINEMATIC — drawIntroText (UPDATED)
//  Displays "IRAN USA WAR" centered on screen for 2 seconds.
// =============================================================================
void drawIntroText()
{
    // dark background
    glColor3f(0.0f, 0.0f, 0.0f);
    drawRect(0, 0, 1024, 480);




    glColor3f(1.0f, 0.0f, 0.0f);     // gold/yellow
    glRasterPos2f(240.0f, 255.0f);
    const char* title = "Iran USA Border Conflict Zone: A 2D Computer Graphics Scene";
    for (const char* c = title; *c; c++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *c);

    // --- Line 2: subtitle in smaller font ---
    glColor3f(1.0f, 1.0f, 1.0f);    // white
    glRasterPos2f(450.0f, 225.0f);
    const char* sub = "GROUP- C";
    for (const char* c = sub; *c; c++)
        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, *c);
}

//  ANIMATION TIMER
void update(int value)
{
    float dt = 0.03f;

    if (sceneState == INTRO_EXPLOSION) {
        introT += dt;
        if (introT >= 2.0f) {
            sceneState = INTRO_TEXT;
            introT = 0.0f;
        }
        glutPostRedisplay();
        glutTimerFunc(33, update, 0);
        return;
    }

    if (sceneState == INTRO_TEXT) {
        introT += dt;
        if (introT >= 2.0f) {
            sceneState = NORMAL;
        }
        glutPostRedisplay();
        glutTimerFunc(33, update, 0);
        return;
    }

    if (sceneState == NORMAL) {
        t += dt;

        heliX += 4.5f;
        if (heliX > 1150) heliX = -120;
        heliY = 380 + sin(t * 1.5f) * 4;
        bladeAngle += 18.0f;
        if (bladeAngle > 360) bladeAngle -= 360;

        wheelAngle += 6.0f;
        if (wheelAngle > 360) wheelAngle -= 360;
        treadShift -= 1.0f;

        satPhase += 0.03f;

        flagPhase += 0.20f;
        spotSweep += 0.025f;
        cloudShift += 0.08f;
        fogShift += 0.5f;

        jetUSAx += 5.15f;
        if (jetUSAx > 1100) jetUSAx = -50;

        jetIRNx -= 5.15f;
        if (jetIRNx < -50) jetIRNx = 1100;

        starTwinkle += 0.05f;
        windowPulse += 0.04f;
        antennaBlink += 0.1f;
        soldierBob += 0.08f;

        missileT += dt / 1.5f;
        if (missileT > 1.0f) {
            if (missileT > 1.0f + 2.0f / 1.5f) {
                missileT = 0.0f;
                shockwave = 0.0f;
            }
        }

        if (shockwave < 1.0f)
            shockwave += dt / 1.2f;

        if ((int)(t * 30) % 2 == 0) spawnSmoke();
        for (int i = 0; i < MAX_SMOKE; i++) {
            if (smoke[i].alive) {
                smoke[i].age += dt;
                smoke[i].x += smoke[i].vx;
                smoke[i].y += smoke[i].vy;
                smoke[i].vy *= 0.99f;
                if (smoke[i].age >= smoke[i].life) smoke[i].alive = false;
            }
        }



        float skyTime = fmod(t, 8.0f);
        if (skyTime < 2.0f) skyStage = 0;
        else if (skyTime < 4.0f) skyStage = 1;
        else if (skyTime < 6.0f) skyStage = 2;
        else skyStage = 3;

        if (!tankUSADone) {
            tankUSAx += 2.0f;
            if (tankUSAx >= 228.0f) { tankUSAx = 228.0f; tankUSADone = true; }
        }
        if (!tankIRNDone) {
            tankIRNx -= 2.0f;
            if (tankIRNx <= 806.0f) { tankIRNx = 806.0f; tankIRNDone = true; }
        }

        if (!boardParked) {
            boardX += 2.5f;
            if (boardX >= boardTarget) { boardX = boardTarget; boardParked = true; }
        }

        for (int i = 0; i < 3; i++) {
            droneUSAx[i] += 0.5f;
            if (droneUSAx[i] > 1100.0f) droneUSAx[i] = -40.0f;
            droneIRNx[i] -= 0.5f;
            if (droneIRNx[i] < -100.0f) droneIRNx[i] = 1100.0f;
        }
    }

    glutPostRedisplay();
    glutTimerFunc(33, update, 0);
}
//  DISPLAY

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    if (sceneState == INTRO_EXPLOSION) {
        drawIntroExplosion(introT);
    }
    else if (sceneState == INTRO_TEXT) {
        drawIntroText();
    }
    else {
        drawZone1_Background();
        drawSatellite();
        drawZone2_Border();
        drawZone3_USA();
        drawZone4_Iran();
        drawDrones();
        drawZone1_Foreground();
        drawHelicopter();
    }

    glutSwapBuffers();
}

void init() {
    glClearColor(0,0,0,1);
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    gluOrtho2D(0,1024,0,480);
    glMatrixMode(GL_MODELVIEW);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT,GL_NICEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
    for (int i=0;i<MAX_SMOKE; i++) smoke[i].alive=false;
    srand(42);
}

int main(int argc, char** argv) {
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
    glutInitWindowSize(1024,480);
    glutInitWindowPosition(50,50);
    glutCreateWindow("Iran-USA WAR Scene");
    init();
    glutDisplayFunc(display);
    glutTimerFunc(0,update,0);
    glutMainLoop();
    return 0;
}
